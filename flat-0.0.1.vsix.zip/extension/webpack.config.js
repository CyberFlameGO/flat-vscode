const path = require("path");
const { IgnorePlugin } = require("webpack");
const FilterWarningsPlugin = require("webpack-filter-warnings-plugin");

module.exports = {
  target: "node",
  mode: "production",
  entry: "./out/extension.js",
  output: {
    filename: "extension.js",
    path: path.resolve(__dirname, "out"),
  },
  devtool: "source-map",
  externals: {
    vscode: "commonjs vscode",
  },
  resolve: {
    // support reading TypeScript and JavaScript files, 📖 -> https://github.com/TypeStrong/ts-loader
    extensions: [".ts", ".js"],
  },
  plugins: [
    new IgnorePlugin({
      resourceRegExp: /^pg-native$/,
    }),
    new IgnorePlugin({
      resourceRegExp: /^vscode$/,
    }),
    new FilterWarningsPlugin({
      exclude: [
        /mongodb/,
        /mssql/,
        /mysql/,
        /mysql2/,
        /oracledb/,
        /pg/,
        /pg-native/,
        /pg-query-stream/,
        /react-native-sqlite-storage/,
        /redis/,
        /sqlite3/,
        /sql.js/,
        /typeorm-aurora-data-api-driver/,
      ],
    }),
  ],
};
